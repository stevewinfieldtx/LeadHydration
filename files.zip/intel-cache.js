/**
 * LeadHydration — Intel Cache Middleware
 * ═══════════════════════════════════════════════════════════════════
 *
 * Drop-in cache layer that wraps existing agent calls with TDE
 * intelligence cache lookups. Check TDE first → use cached data
 * if fresh → only research what's stale or missing → write back.
 *
 * USAGE in server.js:
 *   const { intelCache } = require('./intel-cache');
 *
 *   // Before calling an agent, check cache:
 *   const cached = await intelCache.getCompany(domain);
 *   if (cached.found && cached.freshness.sections.industry.fresh) {
 *     // Use cached.sections.industry.data instead of calling agent
 *   }
 *
 *   // After agent returns, store the result:
 *   await intelCache.storeCompanySection(domain, companyName, 'industry', agentResult, { industry, country });
 *
 * REQUIRES: TDE_BASE_URL and TDE_API_KEY env vars (already configured)
 */

const axios = require('axios');

const TDE_BASE_URL = process.env.TDE_BASE_URL || 'https://targeteddecomposition-production.up.railway.app';
const TDE_API_KEY = process.env.TDE_API_KEY || '';

function available() { return !!TDE_API_KEY && !!TDE_BASE_URL; }

async function tdeIntelRequest(method, path, body) {
  const opts = {
    method,
    url: `${TDE_BASE_URL}${path}`,
    headers: { 'Content-Type': 'application/json', 'X-API-KEY': TDE_API_KEY },
    timeout: 15000, // cache ops should be fast
  };
  if (body) opts.data = body;
  const r = await axios(opts);
  return r.data;
}

function domainFromUrl(url) {
  return (url || '')
    .replace(/^https?:\/\//, '')
    .replace(/^www\./, '')
    .replace(/\/.*$/, '')
    .toLowerCase()
    .trim();
}

function slugify(str) {
  return (str || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .substring(0, 120);
}

// ═══════════════════════════════════════════════════════════════════════════
// COMPANY CACHE OPERATIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Look up a company in the intel cache.
 * Returns { found, freshness, sections } or { found: false }
 */
async function getCompany(domainOrUrl) {
  if (!available()) return { found: false, reason: 'tde_not_configured' };
  const domain = domainFromUrl(domainOrUrl);
  try {
    const result = await tdeIntelRequest('GET', `/intel/company/${encodeURIComponent(domain)}`);
    return result;
  } catch (e) {
    console.log(`[Intel Cache] Company lookup failed for ${domain}: ${e.message}`);
    return { found: false, reason: 'lookup_error', error: e.message };
  }
}

/**
 * Store a specific section of company intelligence.
 * @param {string} domainOrUrl - Company domain
 * @param {string} companyName - Human-readable name
 * @param {string} section - One of: industry, painpoints, company_pain, customer, compete, contacts, leadership
 * @param {object} data - The agent result to cache
 * @param {object} meta - Additional fields: { industry, country, sic_code, etc. }
 */
async function storeCompanySection(domainOrUrl, companyName, section, data, meta = {}) {
  if (!available()) return { ok: false, reason: 'tde_not_configured' };
  const domain = domainFromUrl(domainOrUrl);
  try {
    const body = {
      company_name: companyName,
      website: domainOrUrl,
      sections: { [section]: data },
      ...meta, // industry, country, sic_code, naics_code, etc.
    };
    const result = await tdeIntelRequest('PUT', `/intel/company/${encodeURIComponent(domain)}`, body);
    console.log(`[Intel Cache] Stored ${section} for ${domain}`);
    return result;
  } catch (e) {
    console.log(`[Intel Cache] Store failed for ${domain}:${section}: ${e.message}`);
    return { ok: false, reason: 'store_error', error: e.message };
  }
}

/**
 * Store full company record (all sections at once, e.g., after a complete hydration run).
 */
async function storeCompanyFull(domainOrUrl, companyName, allSections, meta = {}) {
  if (!available()) return { ok: false, reason: 'tde_not_configured' };
  const domain = domainFromUrl(domainOrUrl);
  try {
    const body = {
      company_name: companyName,
      website: domainOrUrl,
      sections: allSections,
      ...meta,
    };
    const result = await tdeIntelRequest('PUT', `/intel/company/${encodeURIComponent(domain)}`, body);
    console.log(`[Intel Cache] Full store for ${domain} (${Object.keys(allSections).length} sections)`);
    return result;
  } catch (e) {
    console.log(`[Intel Cache] Full store failed for ${domain}: ${e.message}`);
    return { ok: false, reason: 'store_error', error: e.message };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// INDUSTRY CACHE OPERATIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Look up industry intelligence.
 * @param {string} industryName - e.g. "Discrete Manufacturing"
 * @param {string} [solutionKey] - e.g. "sap-business-one" to check solution-pain cache
 */
async function getIndustry(industryName, solutionKey) {
  if (!available()) return { found: false, reason: 'tde_not_configured' };
  const key = slugify(industryName);
  try {
    let path = `/intel/industry/${encodeURIComponent(key)}`;
    if (solutionKey) path += `?solution_key=${encodeURIComponent(solutionKey)}`;
    const result = await tdeIntelRequest('GET', path);
    return result;
  } catch (e) {
    console.log(`[Intel Cache] Industry lookup failed for ${key}: ${e.message}`);
    return { found: false, reason: 'lookup_error', error: e.message };
  }
}

/**
 * Store industry intelligence.
 * @param {string} industryName
 * @param {object} data - { pain_points, trends, regulations, tech_landscape }
 * @param {object} [solutionPains] - { "sap-business-one": { painPoints: [...] } }
 */
async function storeIndustry(industryName, data, solutionPains = null) {
  if (!available()) return { ok: false, reason: 'tde_not_configured' };
  const key = slugify(industryName);
  try {
    const body = {
      industry_name: industryName,
      ...data,
    };
    if (solutionPains) body.solution_pains = solutionPains;
    const result = await tdeIntelRequest('PUT', `/intel/industry/${encodeURIComponent(key)}`, body);
    console.log(`[Intel Cache] Industry stored: ${key}`);
    return result;
  } catch (e) {
    console.log(`[Intel Cache] Industry store failed for ${key}: ${e.message}`);
    return { ok: false, reason: 'store_error', error: e.message };
  }
}

/**
 * Store solution-specific pain points for an industry.
 * This is the key optimization: industry + solution pain points are the
 * SAME for every company in that industry. Research once, reuse forever.
 */
async function storeIndustrySolutionPains(industryName, solutionKey, painPointsData) {
  if (!available()) return { ok: false, reason: 'tde_not_configured' };
  const key = slugify(industryName);
  try {
    const body = {
      industry_name: industryName,
      solution_pains: { [solutionKey]: painPointsData },
    };
    const result = await tdeIntelRequest('PUT', `/intel/industry/${encodeURIComponent(key)}`, body);
    console.log(`[Intel Cache] Solution pains stored: ${key} × ${solutionKey}`);
    return result;
  } catch (e) {
    console.log(`[Intel Cache] Solution pains store failed: ${e.message}`);
    return { ok: false, reason: 'store_error', error: e.message };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SMART AGENT WRAPPERS
// ═══════════════════════════════════════════════════════════════════════════
// These wrap the existing agent calls with cache-first logic.
// Drop these into your existing batch flow to eliminate redundant calls.

/**
 * Smart industry classification — checks cache before calling the agent.
 * @param {Function} agentFn - The actual agent call: async (params) => agentResult
 * @param {object} params - { companyName, website, address, country, skipSignalScan }
 * @returns {object} Agent result (from cache or fresh)
 */
async function smartIndustryAgent(agentFn, params) {
  const domain = domainFromUrl(params.website);
  const cached = await getCompany(domain);

  // Check if industry classification is cached and fresh
  if (cached.found && cached.freshness?.sections?.industry?.fresh) {
    const data = cached.sections?.industry?.data;
    if (data && data.industry) {
      console.log(`[Intel Cache] CACHE HIT: industry for ${domain} → ${data.industry}`);
      return { ...data, _cache: 'hit', _cache_age: cached.sections.industry.researched_at };
    }
  }

  // Cache miss or stale — call the real agent
  console.log(`[Intel Cache] CACHE MISS: industry for ${domain} — calling agent`);
  const result = await agentFn(params);

  // Store the result
  await storeCompanySection(domain, params.companyName, 'industry', result, {
    industry: result.industry,
    sub_industry: result.subIndustry,
    sic_code: result.sicCode,
    naics_code: result.naicsCode,
    local_code: result.localCode,
    local_code_system: result.localCodeSystem,
    country: params.country,
    address: params.address,
    classification_confidence: result.confidence,
    classification_source: result.contentSource,
  });

  return { ...result, _cache: 'miss' };
}

/**
 * Smart pain points agent — checks industry cache before calling.
 * This is the big saver: industry + solution pain points are identical
 * for all companies in the same industry.
 */
async function smartPainPointsAgent(agentFn, params) {
  const { industry, solution } = params;
  const solutionKey = slugify(solution?.name || solution?.url || 'unknown');

  // Check industry-level pain cache
  const cached = await getIndustry(industry, solutionKey);
  if (cached.found && cached.solution_pain_cache?.found && cached.solution_pain_cache?.fresh) {
    console.log(`[Intel Cache] CACHE HIT: pain points for ${industry} × ${solutionKey}`);
    return { ...cached.solution_pain_cache, _cache: 'hit' };
  }

  // Cache miss — call the real agent
  console.log(`[Intel Cache] CACHE MISS: pain points for ${industry} × ${solutionKey} — calling agent`);
  const result = await agentFn(params);

  // Store at industry level (reusable for ALL companies in this industry)
  await storeIndustrySolutionPains(industry, solutionKey, result);

  // Also ensure the industry record exists with basic info
  if (!cached.found) {
    await storeIndustry(industry, { pain_points: result.painPoints || [] });
  }

  return { ...result, _cache: 'miss' };
}

/**
 * Smart company pain agent — checks company cache before calling.
 */
async function smartCompanyPainAgent(agentFn, params) {
  const domain = domainFromUrl(params.website);
  const cached = await getCompany(domain);

  if (cached.found && cached.freshness?.sections?.company_pain?.fresh) {
    const data = cached.sections?.company_pain?.data;
    if (data) {
      console.log(`[Intel Cache] CACHE HIT: company pain for ${domain}`);
      return { ...data, _cache: 'hit', _cache_age: cached.sections.company_pain.researched_at };
    }
  }

  console.log(`[Intel Cache] CACHE MISS: company pain for ${domain} — calling agent`);
  const result = await agentFn(params);

  await storeCompanySection(domain, params.companyName, 'company_pain', result);
  return { ...result, _cache: 'miss' };
}

/**
 * Smart customer research agent — checks company cache before calling.
 */
async function smartCustomerAgent(agentFn, params) {
  const domain = domainFromUrl(params.website);
  const cached = await getCompany(domain);

  if (cached.found && cached.freshness?.sections?.customer?.fresh) {
    const data = cached.sections?.customer?.data;
    if (data) {
      console.log(`[Intel Cache] CACHE HIT: customer research for ${domain}`);
      return { ...data, _cache: 'hit' };
    }
  }

  console.log(`[Intel Cache] CACHE MISS: customer research for ${domain} — calling agent`);
  const result = await agentFn(params);

  await storeCompanySection(domain, params.companyName, 'customer', result);
  return { ...result, _cache: 'miss' };
}

/**
 * Smart compete-detect — checks company cache before calling.
 */
async function smartCompeteAgent(agentFn, params) {
  const domain = domainFromUrl(params.website);
  const cached = await getCompany(domain);

  if (cached.found && cached.freshness?.sections?.compete?.fresh) {
    const data = cached.sections?.compete?.data;
    if (data) {
      console.log(`[Intel Cache] CACHE HIT: compete-detect for ${domain}`);
      return { ...data, _cache: 'hit' };
    }
  }

  console.log(`[Intel Cache] CACHE MISS: compete-detect for ${domain} — calling agent`);
  const result = await agentFn(params);

  await storeCompanySection(domain, params.companyName, 'compete', result);
  return { ...result, _cache: 'miss' };
}

// ═══════════════════════════════════════════════════════════════════════════
// BATCH HELPER — Process a list of companies with cache optimization
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Pre-check a batch of companies against the cache.
 * Returns { cached: [...], uncached: [...], partial: [...] }
 * This lets you skip entire companies that are fully cached.
 */
async function batchPrecheck(companies) {
  if (!available()) {
    return { cached: [], uncached: companies, partial: [], stats: { total: companies.length, cache_available: false } };
  }

  const cached = [];
  const uncached = [];
  const partial = [];

  for (const company of companies) {
    const domain = domainFromUrl(company.website || company.url || '');
    if (!domain) { uncached.push(company); continue; }

    try {
      const result = await getCompany(domain);
      if (result.found && result.freshness?.all_fresh) {
        cached.push({ ...company, _cached_intel: result });
      } else if (result.found) {
        partial.push({ ...company, _cached_intel: result, _stale_sections: result.freshness?.stale_sections || [] });
      } else {
        uncached.push(company);
      }
    } catch {
      uncached.push(company);
    }
  }

  const stats = {
    total: companies.length,
    fully_cached: cached.length,
    partially_cached: partial.length,
    uncached: uncached.length,
    estimated_api_calls_saved: cached.length * 4, // ~4 agent calls per company
  };

  console.log(`[Intel Cache] Batch precheck: ${stats.fully_cached} cached, ${stats.partially_cached} partial, ${stats.uncached} uncached (est. ${stats.estimated_api_calls_saved} API calls saved)`);

  return { cached, uncached, partial, stats };
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════════════════════════════════════

module.exports = {
  intelCache: {
    available,

    // Direct cache operations
    getCompany,
    storeCompanySection,
    storeCompanyFull,
    getIndustry,
    storeIndustry,
    storeIndustrySolutionPains,

    // Smart agent wrappers (cache-first)
    smartIndustryAgent,
    smartPainPointsAgent,
    smartCompanyPainAgent,
    smartCustomerAgent,
    smartCompeteAgent,

    // Batch optimization
    batchPrecheck,
  }
};
